# OptionPilot India — Angel One SmartAPI web app

This is the **web app only** version. It is a personal, browser-based options paper-trading terminal using Angel One SmartAPI for live market quotes.

## Data integrity rules

- Live data only. No generated, simulated, estimated, or fabricated prices.
- If login fails, a quote is missing, or the market-data request fails, the app displays an error and disables paper orders.
- The app never calls Angel One order-placement endpoints. All orders and positions are stored locally in this browser.
- The virtual wallet remains unlimited.
- Quotes are requested from Angel One's market-data API; the option chain is assembled from Angel One's public instrument master and live NFO quotes.
- No Sensibull/NSE webpage scraping is used.

## What you need

1. An Angel One account eligible for SmartAPI.
2. A SmartAPI application/API key from https://smartapi.angelone.in/.
3. Your Angel One client code and MPIN.
4. TOTP enabled on your Angel One account and the Base32 TOTP secret from the authenticator setup.
5. Node.js 20 or newer.

Angel One describes SmartAPI as free and documents live WebSocket/market-data APIs. Access still depends on your account, SmartAPI app and current provider conditions. Check the official FAQ and documentation before relying on availability:
- https://smartapi.angelone.in/docs
- https://smartapi.angelbroking.com/faq
- https://www.angelone.in/knowledge-center/smartapi/detailed-introduction-to-smartapi

## Run locally on Windows

1. Extract the ZIP.
2. Open the `server` folder in Command Prompt.
3. Install dependencies:

   ```bat
   npm install
   ```

4. Copy `.env.example` to `.env` inside `server`.
5. Edit `server/.env` and fill in your own API key, client code, MPIN and Base32 TOTP secret. Do not share this file or upload it to GitHub.
6. Set `ANGEL_CLIENT_PUBLIC_IP` to the public IPv4 address Angel One expects for your SmartAPI application. If your app configuration does not require a fixed public IP, follow Angel One's current instructions. The sample `127.0.0.1` may be rejected by some accounts.
7. Start the server:

   ```bat
   npm start
   ```

8. Open http://localhost:8787 in your browser.
9. Go to Settings → **Connect Angel One**. Then choose an underlying and expiry and click **Load live chain**.

## Security

- Never enter your MPIN, API key, or TOTP secret into the web page. They belong only in `server/.env`.
- Never commit `.env` to GitHub or send it in screenshots/messages.
- Keep the backend private. For public hosting, configure `APP_ORIGIN` to your exact site origin and add an authentication/access-control layer at the hosting reverse proxy before exposing it. Do not run an unauthenticated personal broker-data backend on a public URL.
- Angel One login sessions and tokens are held in server memory only and are cleared when you press Disconnect or restart the backend.

## Current implementation notes

- Supports NIFTY, BANKNIFTY and FINNIFTY index options.
- Loads the selected expiry from Angel One's instrument master, obtains a live underlying quote, selects the 21 nearest strikes around ATM, and requests actual NFO option quotes.
- SmartAPI quote responses can omit instruments or reject a request. Missing quotes are shown as unavailable; they are never replaced with synthetic values.
- Live chain refresh runs at the interval selected in Settings. Paper orders require a recent valid quote (maximum 60 seconds old).
- IV/Greeks are not currently populated in this version because the chain is based on actual quote fields; unavailable fields remain blank rather than estimated.
- The quote requests are spaced to respect the documented 1-request-per-second quote endpoint limit. Market-data endpoint limits and Angel One API behaviour can change. The backend returns provider errors directly for diagnosis.

## API endpoints

- `GET /api/health` — backend/provider configuration and session status.
- `POST /api/connect` — SmartAPI login using server-side MPIN and TOTP.
- `POST /api/disconnect` — clear the in-memory session.
- `GET /api/option-chain?symbol=NIFTY&expiry=YYYY-MM-DD` — retrieve actual Angel One quotes.

This is an educational paper-trading tool, not investment advice. It does not execute real trades.


## Authentication header fix
The market-data backend sends the SmartAPI JWT as `Authorization: Bearer <jwt>`. This is required by Angel One for all authenticated endpoints except login. The included diagnostic script uses the same header. No simulated or cached prices are used.


## Bootstrap dashboard (2026-11-06)
- Responsive Bootstrap 5.3.3 UI via CDN (internet needed for styling).
- Uses Angel One SmartAPI authenticated Bearer JWT; no live prices are generated or cached.
- Keep your existing private `server/.env`; it is deliberately excluded from this ZIP.
- Run `cd server`, `npm install`, `npm start`, then open `http://localhost:8787`.
- Refresh browser with Ctrl+Shift+R after updating to discard older service-worker UI.
- Paper positions/order history live in the browser's localStorage.


## Automatic startup and live dashboard updates
The dashboard automatically checks backend health, creates an Angel One session from server/.env, selects the nearest upcoming expiry, and loads the live option chain. It displays the underlying spot quote, exchange-feed timestamp, progress steps, and activity log. Quote polling defaults to 5 seconds (minimum) to avoid aggressive REST API requests/rate limits; displayed P&L is recalculated every second using the latest verified quote. This is not tick-by-tick streaming and cannot guarantee zero latency.

import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import dotenv from 'dotenv';
import os from 'node:os';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { TOTP, Secret } from 'otpauth';

dotenv.config();
const app = express();
const PORT = Number(process.env.PORT || 8787);
const API_ROOT = 'https://apiconnect.angelone.in';
const MASTER_URL = 'https://margincalculator.angelone.in/OpenAPI_File/files/OpenAPIScripMaster.json';
const allowedOrigin = process.env.APP_ORIGIN || 'http://localhost:8787,http://127.0.0.1:8787';
app.use(helmet({ crossOriginResourcePolicy: { policy: 'cross-origin' }, contentSecurityPolicy: false }));
app.use(cors({ origin: allowedOrigin === '*' ? true : allowedOrigin.split(',').map(x => x.trim()) }));
app.use(express.json({ limit: '32kb' }));
const __dirname = path.dirname(fileURLToPath(import.meta.url));
app.use(express.static(path.join(__dirname, '..', 'public')));

let session = null;
let masterCache = { at: 0, rows: null };
let loginLock = false;
let lastLoginAttempt = 0;
const required = ['ANGEL_API_KEY','ANGEL_CLIENT_CODE','ANGEL_MPIN','ANGEL_TOTP_SECRET'];
const hasConfig = () => required.every(k => String(process.env[k] || '').trim());
const localIp = () => {
  for (const list of Object.values(os.networkInterfaces())) for (const n of (list || [])) if (n.family === 'IPv4' && !n.internal) return n.address;
  return '127.0.0.1';
};
const macAddress = () => {
  for (const list of Object.values(os.networkInterfaces())) for (const n of (list || [])) if (n.family === 'IPv4' && !n.internal && n.mac && n.mac !== '00:00:00:00:00:00') return n.mac;
  return '00:00:00:00:00:00';
};
const headers = () => ({
  'Content-Type': 'application/json', 'Accept': 'application/json',
  'X-UserType': 'USER', 'X-SourceID': process.env.ANGEL_SOURCE_ID || 'WEB',
  'X-PrivateKey': process.env.ANGEL_API_KEY,
  'X-ClientLocalIP': process.env.ANGEL_CLIENT_LOCAL_IP || localIp(),
  'X-ClientPublicIP': process.env.ANGEL_CLIENT_PUBLIC_IP || '127.0.0.1',
  'X-MACAddress': process.env.ANGEL_MAC_ADDRESS || macAddress()
});
function safeError(message, status=400) { const e = new Error(message); e.status = status; return e; }
async function login() {
  if (!hasConfig()) throw safeError('Angel One credentials are not configured on the server. Add the four ANGEL_* values to server/.env.', 503);
  if (loginLock) throw safeError('Angel One login is already in progress. Please retry shortly.', 409);
  if (Date.now() - lastLoginAttempt < 5000) throw safeError('Please wait a few seconds before retrying Angel One login.', 429);
  lastLoginAttempt = Date.now();
  loginLock = true;
  try {
    const totp = new TOTP({ secret: Secret.fromBase32(process.env.ANGEL_TOTP_SECRET.replace(/\s/g, '').toUpperCase()) }).generate();
    const response = await fetch(`${API_ROOT}/rest/auth/angelbroking/user/v1/loginByPassword`, {
      method: 'POST', headers: headers(),
      body: JSON.stringify({ clientcode: process.env.ANGEL_CLIENT_CODE, password: process.env.ANGEL_MPIN, totp })
    });
    const body = await response.json().catch(() => ({}));
    if (!response.ok || body.status !== true || !body.data?.jwtToken || !body.data?.feedToken) {
      session = null;
      throw safeError(body.message || body.errorcode || `Angel One login failed (HTTP ${response.status}). Check API key, client code, MPIN, TOTP secret, IP and SmartAPI access.`, 502);
    }
    session = { jwt: body.data.jwtToken, refresh: body.data.refreshToken, feed: body.data.feedToken, at: Date.now() };
    return true;
  } finally { loginLock = false; }
}
async function ensureSession() {
  // SmartAPI sessions expire; require explicit reconnect rather than silently generating repeat logins.
  if (!session || Date.now() - session.at > 10 * 60 * 60 * 1000) throw safeError('Angel One session is not connected or has expired. Press Connect Angel One and authenticate again.', 401);
}
async function apiPost(path, payload) {
  await ensureSession();
  const h = headers(); h.Authorization = `Bearer ${session.jwt}`; h['X-ClientCode'] = process.env.ANGEL_CLIENT_CODE;
  const r = await fetch(`${API_ROOT}${path}`, { method: 'POST', headers: h, body: JSON.stringify(payload) });
  const j = await r.json().catch(() => ({}));
  if (!r.ok || j.status !== true) {
    if (r.status === 401 || /token/i.test(j.message || '')) session = null;
    throw safeError(j.message || j.errorcode || `Angel One market-data request failed (HTTP ${r.status}).`, r.status === 401 ? 401 : 502);
  }
  return j.data;
}
async function getMaster() {
  if (masterCache.rows && Date.now() - masterCache.at < 60 * 60 * 1000) return masterCache.rows;
  const r = await fetch(MASTER_URL, { headers: { Accept: 'application/json' } });
  if (!r.ok) throw safeError(`Angel One instrument master unavailable (HTTP ${r.status}).`, 502);
  const rows = await r.json();
  if (!Array.isArray(rows)) throw safeError('Angel One instrument master returned an unexpected format.', 502);
  masterCache = { at: Date.now(), rows };
  return rows;
}
const INDEX = {
  NIFTY: { token: '99926000', name: 'Nifty 50' },
  BANKNIFTY: { token: '99926009', name: 'Nifty Bank' },
  FINNIFTY: { token: '99926037', name: 'Nifty Fin Service' }
};
const expiryCode = iso => {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(iso || '')) throw safeError('Expiry must be YYYY-MM-DD.');
  const d = new Date(`${iso}T00:00:00Z`);
  if (Number.isNaN(d.getTime())) throw safeError('Invalid expiry date.');
  return `${String(d.getUTCDate()).padStart(2,'0')}${d.toLocaleString('en-US',{month:'short',timeZone:'UTC'}).toUpperCase()}${d.getUTCFullYear()}`;
};
function quoteMap(data) {
  const out = new Map();
  for (const q of (data?.fetched || [])) out.set(String(q.symbolToken), q);
  if (Array.isArray(data)) for (const q of data) out.set(String(q.symbolToken || q.token), q);
  return out;
}
const val = (...xs) => { for (const x of xs) if (x !== undefined && x !== null && x !== '') return Number(x); return null; };
function parseFeedTime(value) {
  if (!value) return null;
  const raw = String(value).trim();
  const m = raw.match(/^(\d{1,2})-([A-Za-z]{3})-(\d{4})[ T](\d{2}):(\d{2}):(\d{2})$/);
  if (m) { const d = new Date(`${m[1]} ${m[2]} ${m[3]} ${m[4]}:${m[5]}:${m[6]} GMT+0530`); return Number.isNaN(d.getTime()) ? null : d; }
  // Angel One exchange timestamps without an explicit zone are interpreted as India Standard Time.
  const isoWithoutZone = /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d+)?$/;
  const d = new Date(isoWithoutZone.test(raw) ? `${raw}+05:30` : raw);
  return Number.isNaN(d.getTime()) ? null : d;
}
function isFreshQuote(q, maxAgeMs = 90000) {
  const t = parseFeedTime(q?.exchangeFeedTime || q?.exchFeedTime);
  return !!t && Math.abs(Date.now() - t.getTime()) <= maxAgeMs;
}

app.get('/api/health', (_req,res) => res.json({ status: 'ok', provider: 'Angel One SmartAPI', configured: hasConfig(), connected: Boolean(session), dataMode: 'LIVE_ONLY', simulatedPrices: false, timestamp: new Date().toISOString() }));
app.get('/api/expiries', async (req,res) => {
  try { const symbol=String(req.query.symbol||'NIFTY').toUpperCase(); if(!INDEX[symbol]) throw safeError('Unsupported underlying.'); const rows=await getMaster(); const today=new Date(); const dates=[...new Set(rows.filter(x=>x.exch_seg==='NFO'&&x.instrumenttype==='OPTIDX'&&x.name===symbol).map(x=>String(x.expiry||'').toUpperCase()).filter(Boolean))].map(code=>{ const m=code.match(/^(\d{2})([A-Z]{3})(\d{4})$/); if(!m)return null; const months={JAN:0,FEB:1,MAR:2,APR:3,MAY:4,JUN:5,JUL:6,AUG:7,SEP:8,OCT:9,NOV:10,DEC:11}; const d=new Date(Number(m[3]),months[m[2]],Number(m[1])); return Number.isNaN(d.getTime())?null:{code,iso:d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0')+'-'+String(d.getDate()).padStart(2,'0'),time:d.getTime()}; }).filter(x=>x&&x.time>=new Date(today.getFullYear(),today.getMonth(),today.getDate()).getTime()).sort((a,b)=>a.time-b.time); res.json({status:'ok',symbol,expiries:dates.map(x=>({expiry:x.iso,code:x.code})),defaultExpiry:dates[0]?.iso||null}); } catch(e){res.status(e.status||500).json({status:'error',message:e.message,expiries:[]});}
});
app.post('/api/connect', async (_req,res) => {
  try { await login(); res.json({ status: 'ok', provider: 'Angel One SmartAPI', connected: true, message: 'Angel One session connected. Live market data can now be requested.', timestamp: new Date().toISOString() }); }
  catch(e) { res.status(e.status || 500).json({ status: 'error', connected: false, message: e.message }); }
});
app.post('/api/disconnect', (_req,res) => { session = null; res.json({ status: 'ok', connected: false, message: 'Local SmartAPI session cleared.' }); });
app.get('/api/option-chain', async (req,res) => {
  try {
    await ensureSession();
    const symbol = String(req.query.symbol || 'NIFTY').toUpperCase();
    if (!INDEX[symbol]) throw safeError('Unsupported underlying. Choose NIFTY, BANKNIFTY or FINNIFTY.');
    const rows = await getMaster();
    let requestedExpiry = String(req.query.expiry || '');
    if (!requestedExpiry) {
      const candidates = [...new Set(rows.filter(x=>x.exch_seg==='NFO'&&x.instrumenttype==='OPTIDX'&&x.name===symbol).map(x=>String(x.expiry||'').toUpperCase()))].map(code=>{const m=code.match(/^(\d{2})([A-Z]{3})(\d{4})$/);if(!m)return null;const months={JAN:0,FEB:1,MAR:2,APR:3,MAY:4,JUN:5,JUL:6,AUG:7,SEP:8,OCT:9,NOV:10,DEC:11};const d=new Date(Number(m[3]),months[m[2]],Number(m[1]));return Number.isNaN(d.getTime())?null:{code,time:d.getTime(),iso:d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0')+'-'+String(d.getDate()).padStart(2,'0')};}).filter(x=>x&&x.time>=new Date().setHours(0,0,0,0)).sort((a,b)=>a.time-b.time);
      if(!candidates.length) throw safeError(`No upcoming expiry found for ${symbol}.`,404);
      requestedExpiry=candidates[0].iso;
    }
    const expiry = expiryCode(requestedExpiry);
    const options = rows.filter(x => x.exch_seg === 'NFO' && x.instrumenttype === 'OPTIDX' && x.name === symbol && String(x.expiry || '').toUpperCase() === expiry && /(?:CE|PE)$/.test(x.symbol || ''));
    if (!options.length) throw safeError(`No Angel One option contracts found for ${symbol} expiry ${expiry}. Check the expiry date and instrument master.`, 404);
    const spotToken = INDEX[symbol].token;
    const spotData = await apiPost('/rest/secure/angelbroking/market/v1/quote/', { mode: 'FULL', exchangeTokens: { NSE: [spotToken] } });
    const spotQ = quoteMap(spotData).get(spotToken) || (spotData?.fetched || []).find(x => String(x.symbolToken) === spotToken);
    const spot = val(spotQ?.ltp, spotQ?.lastTradedPrice);
    if (!(spot > 0)) throw safeError(`Angel One did not return a valid live spot price for ${symbol}. Option chain was not loaded.`, 502);
    if (!isFreshQuote(spotQ)) throw safeError(`Angel One spot quote for ${symbol} has no verifiably fresh exchange-feed timestamp (maximum age 90 seconds). Live option data is unavailable.`, 502);
    // SmartAPI's market-data quote endpoint is rate-limited; space the two requests by at least one second.
    await new Promise(resolve => setTimeout(resolve, 1100));
    const strikes = [...new Set(options.map(x => Number(x.strike) / 100).filter(Number.isFinite))].sort((a,b)=>a-b);
    const atm = strikes.reduce((best,s)=>Math.abs(s-spot)<Math.abs(best-spot)?s:best, strikes[0]);
    const center = strikes.indexOf(atm), chosen = strikes.slice(Math.max(0,center-10), Math.min(strikes.length,center+11));
    const chosenSet = new Set(chosen);
    const contracts = options.filter(x => chosenSet.has(Number(x.strike)/100));
    const tokenList = [spotToken, ...contracts.map(x => String(x.token))];
    if (tokenList.length > 50) throw safeError('Selected option chain exceeds SmartAPI single-request limit. Narrow the strike window.', 502);
    const market = await apiPost('/rest/secure/angelbroking/market/v1/quote/', {
      mode: 'FULL', exchangeTokens: { NSE: [spotToken], NFO: contracts.map(x => String(x.token)) }
    });
    const quotes = quoteMap(market);
    const byStrike = new Map();
    for (const inst of contracts) {
      const strike = Number(inst.strike)/100;
      const side = String(inst.symbol).endsWith('CE') ? 'CE' : 'PE';
      const q = quotes.get(String(inst.token));
      if (!q || !isFreshQuote(q)) continue;
      const ltp = val(q.ltp, q.lastTradedPrice);
      const record = { ltp, oi: val(q.opnInterest, q.openInterest, q.oi), volume: val(q.tradeVolume, q.volume), symbol: inst.symbol, token: String(inst.token), lotSize: Number(inst.lotsize || 1), exchange: 'NFO', feedTime: q.exchangeFeedTime || q.exchFeedTime };
      if (!byStrike.has(strike)) byStrike.set(strike, {});
      byStrike.get(strike)[side] = record;
    }
    const chain = chosen.map(strike => {
      const pair = byStrike.get(strike) || {};
      const opt = (v) => v ? { market_data: { ltp: v.ltp, oi: v.oi, volume: v.volume }, option_greeks: {}, trading_symbol: v.symbol, symbol_token: v.token, lot_size: v.lotSize } : null;
      return { strike_price: strike, call_options: opt(pair.CE), put_options: opt(pair.PE) };
    });
    const anyLive = chain.some(r => [r.call_options?.market_data?.ltp, r.put_options?.market_data?.ltp].some(x => Number.isFinite(x) && x > 0));
    if (!anyLive) throw safeError('Angel One returned no valid option LTP values. The chain has been rejected; no prices will be displayed.', 502);
    res.json({ status: 'ok', provider: 'Angel One SmartAPI', symbol, expiry, spot, spotFeedTime: spotQ.exchangeFeedTime || spotQ.exchFeedTime, timestamp: new Date().toISOString(), data: chain, dataMode: 'LIVE_ONLY' });
  } catch(e) { res.status(e.status || 500).json({ status: 'error', message: e.message, data: [], dataMode: 'LIVE_ONLY' }); }
});

app.get('/api/healthz', (_req,res)=>res.json({ok:true}));
app.listen(PORT, () => console.log(`OptionPilot Angel One backend listening on http://localhost:${PORT}`));

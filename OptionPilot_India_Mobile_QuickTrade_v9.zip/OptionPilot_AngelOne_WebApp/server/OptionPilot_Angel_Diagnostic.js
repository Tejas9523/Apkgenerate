/**
 * OptionPilot India — Angel One SmartAPI diagnostic
 *
 * Run from the project's server folder:
 *   node angel-diagnostic.js NIFTY 2026-11-09
 *
 * Requires the existing server/.env and Node.js 20+.
 * This script ONLY logs in and reads market data. It never places orders.
 * Sensitive session tokens and credentials are never printed.
 */

import 'dotenv/config';
import os from 'node:os';
import { TOTP, Secret } from 'otpauth';

const API_ROOT = 'https://apiconnect.angelone.in';
const MASTER_URL =
  'https://margincalculator.angelone.in/OpenAPI_File/files/OpenAPIScripMaster.json';

const symbol = String(process.argv[2] || 'NIFTY').toUpperCase();
const expiryInput = String(process.argv[3] || '');

const INDEX = {
  NIFTY: { token: '99926000', exchange: 'NSE' },
  BANKNIFTY: { token: '99926009', exchange: 'NSE' },
  FINNIFTY: { token: '99926037', exchange: 'NSE' }
};

function assert(condition, message) {
  if (!condition) throw new Error(message);
}

function localNetworkDetails() {
  const interfaces = os.networkInterfaces();
  for (const [name, rows] of Object.entries(interfaces)) {
    for (const row of rows || []) {
      if (row.family === 'IPv4' && !row.internal && row.mac &&
          row.mac !== '00:00:00:00:00:00') {
        return { interfaceName: name, localIp: row.address, mac: row.mac };
      }
    }
  }
  return { interfaceName: null, localIp: '127.0.0.1', mac: '00:00:00:00:00:00' };
}

function makeExpiryCode(iso) {
  assert(/^\d{4}-\d{2}-\d{2}$/.test(iso), 'Expiry must be YYYY-MM-DD.');
  const d = new Date(`${iso}T00:00:00Z`);
  assert(!Number.isNaN(d.getTime()), 'Invalid expiry date.');
  return `${String(d.getUTCDate()).padStart(2, '0')}${d
    .toLocaleString('en-US', { month: 'short', timeZone: 'UTC' })
    .toUpperCase()}${d.getUTCFullYear()}`;
}

function safeJson(value) {
  // Defensive redaction in case an upstream response unexpectedly contains tokens.
  const text = JSON.stringify(value, (key, val) => {
    if (/jwtToken|refreshToken|feedToken|password|mpin|totp|api.?key|authorization/i.test(key)) {
      return '[REDACTED]';
    }
    return val;
  }, 2);
  return text;
}

function printSection(title, value) {
  console.log(`\n${'='.repeat(18)} ${title} ${'='.repeat(18)}`);
  console.log(typeof value === 'string' ? value : safeJson(value));
}

async function requestJson(url, options = {}) {
  const response = await fetch(url, options);
  const body = await response.json().catch(async () => ({
    nonJsonResponse: (await response.text().catch(() => '')).slice(0, 2000)
  }));
  return { httpStatus: response.status, ok: response.ok, body };
}

async function main() {
  console.log('OptionPilot / Angel One read-only diagnostic');
  console.log('No real orders will be placed. Credentials and session tokens will not be printed.');

  assert(INDEX[symbol], `Unsupported symbol ${symbol}. Use NIFTY, BANKNIFTY or FINNIFTY.`);
  assert(expiryInput, 'Usage: node angel-diagnostic.js NIFTY YYYY-MM-DD');

  const required = ['ANGEL_API_KEY', 'ANGEL_CLIENT_CODE', 'ANGEL_MPIN', 'ANGEL_TOTP_SECRET'];
  const missing = required.filter(k => !String(process.env[k] || '').trim());
  printSection('1. LOCAL CONFIGURATION', {
    envLoaded: true,
    requiredVariablesPresent: missing.length === 0,
    missingVariables: missing,
    publicIpConfigured: Boolean(process.env.ANGEL_CLIENT_PUBLIC_IP),
    localNetwork: localNetworkDetails(),
    sourceId: process.env.ANGEL_SOURCE_ID || 'WEB',
    symbol,
    expiry: expiryInput,
    expiryCode: makeExpiryCode(expiryInput)
  });
  assert(missing.length === 0, `Missing .env values: ${missing.join(', ')}`);

  const net = localNetworkDetails();
  const headers = {
    'Content-Type': 'application/json',
    Accept: 'application/json',
    'X-UserType': 'USER',
    'X-SourceID': process.env.ANGEL_SOURCE_ID || 'WEB',
    'X-PrivateKey': process.env.ANGEL_API_KEY,
    'X-ClientLocalIP': process.env.ANGEL_CLIENT_LOCAL_IP || net.localIp,
    'X-ClientPublicIP': process.env.ANGEL_CLIENT_PUBLIC_IP || '',
    'X-MACAddress': process.env.ANGEL_MAC_ADDRESS || net.mac
  };

  console.log('\n[2] Authenticating with Angel One...');
  const totpSecret = process.env.ANGEL_TOTP_SECRET.replace(/\s/g, '').toUpperCase();
  const totp = new TOTP({ secret: Secret.fromBase32(totpSecret) }).generate();
  const loginResult = await requestJson(
    `${API_ROOT}/rest/auth/angelbroking/user/v1/loginByPassword`,
    {
      method: 'POST',
      headers,
      body: JSON.stringify({
        clientcode: process.env.ANGEL_CLIENT_CODE,
        password: process.env.ANGEL_MPIN,
        totp
      })
    }
  );

  const loginBody = loginResult.body || {};
  printSection('2. LOGIN RESPONSE (TOKENS REDACTED)', {
    httpStatus: loginResult.httpStatus,
    httpOk: loginResult.ok,
    status: loginBody.status,
    message: loginBody.message,
    errorcode: loginBody.errorcode,
    dataPresent: Boolean(loginBody.data),
    jwtTokenPresent: Boolean(loginBody.data?.jwtToken),
    refreshTokenPresent: Boolean(loginBody.data?.refreshToken),
    feedTokenPresent: Boolean(loginBody.data?.feedToken)
  });

  assert(loginResult.ok && loginBody.status === true && loginBody.data?.jwtToken,
    `Login failed: ${loginBody.message || loginBody.errorcode || `HTTP ${loginResult.httpStatus}`}`);

  const authHeaders = {
    ...headers,
    Authorization: `Bearer ${loginBody.data.jwtToken}`,
    'X-ClientCode': process.env.ANGEL_CLIENT_CODE
  };

  console.log('\n[3] Downloading Angel One instrument master...');
  const masterResponse = await fetch(MASTER_URL, { headers: { Accept: 'application/json' } });
  assert(masterResponse.ok, `Instrument master failed: HTTP ${masterResponse.status}`);
  const master = await masterResponse.json();
  assert(Array.isArray(master), 'Instrument master response is not a JSON array.');

  const expiryCode = makeExpiryCode(expiryInput);
  const contracts = master.filter(x =>
    x.exch_seg === 'NFO' &&
    x.instrumenttype === 'OPTIDX' &&
    x.name === symbol &&
    String(x.expiry || '').toUpperCase() === expiryCode &&
    /(?:CE|PE)$/.test(x.symbol || '')
  );

  printSection('3. INSTRUMENT MASTER JSON CHECK', {
    httpStatus: masterResponse.status,
    isJsonArray: true,
    totalInstrumentRows: master.length,
    matchingOptionContracts: contracts.length,
    sampleContracts: contracts.slice(0, 4).map(x => ({
      symbol: x.symbol,
      token: x.token,
      strike: x.strike,
      lotsize: x.lotsize,
      expiry: x.expiry,
      exch_seg: x.exch_seg,
      instrumenttype: x.instrumenttype
    }))
  });
  assert(contracts.length > 0, `No contracts found for ${symbol} expiry ${expiryCode}.`);

  async function quoteRequest(payload, label) {
    const result = await requestJson(
      `${API_ROOT}/rest/secure/angelbroking/market/v1/quote/`,
      { method: 'POST', headers: authHeaders, body: JSON.stringify(payload) }
    );
    const body = result.body || {};
    printSection(label, {
      httpStatus: result.httpStatus,
      httpOk: result.ok,
      status: body.status,
      message: body.message,
      errorcode: body.errorcode,
      data: body.data ?? null
    });
    assert(result.ok && body.status === true,
      `${label} failed: ${body.message || body.errorcode || `HTTP ${result.httpStatus}`}`);
    return body.data;
  }

  console.log('\n[4] Requesting live underlying/index quote...');
  const spotData = await quoteRequest({
    mode: 'FULL',
    exchangeTokens: { NSE: [INDEX[symbol].token] }
  }, '4. LIVE SPOT QUOTE JSON');

  const spotQuote = (spotData?.fetched || []).find(
    q => String(q.symbolToken) === INDEX[symbol].token
  );
  const spot = Number(spotQuote?.ltp ?? spotQuote?.lastTradedPrice);
  printSection('5. SPOT VALIDATION', {
    spotQuoteFound: Boolean(spotQuote),
    ltp: Number.isFinite(spot) && spot > 0 ? spot : null,
    exchangeFeedTime: spotQuote?.exchangeFeedTime || spotQuote?.exchFeedTime || null,
    note: 'This diagnostic reports the provider timestamp; verify freshness before using quotes for paper orders.'
  });
  assert(Number.isFinite(spot) && spot > 0, 'No valid live spot LTP returned.');

  const strikes = [...new Set(contracts.map(x => Number(x.strike) / 100).filter(Number.isFinite))]
    .sort((a, b) => a - b);
  const atm = strikes.reduce((best, strike) =>
    Math.abs(strike - spot) < Math.abs(best - spot) ? strike : best, strikes[0]);
  const center = strikes.indexOf(atm);
  const chosenStrikes = strikes.slice(Math.max(0, center - 3), Math.min(strikes.length, center + 4));
  const chosenSet = new Set(chosenStrikes);
  const selected = contracts.filter(x => chosenSet.has(Number(x.strike) / 100));
  const ce = selected.filter(x => String(x.symbol).endsWith('CE'));
  const pe = selected.filter(x => String(x.symbol).endsWith('PE'));
  const tokenMap = {
    NSE: [INDEX[symbol].token],
    NFO: selected.map(x => String(x.token))
  };

  await new Promise(resolve => setTimeout(resolve, 1100));
  console.log('\n[6] Requesting live NFO option quotes...');
  const optionData = await quoteRequest({
    mode: 'FULL',
    exchangeTokens: tokenMap
  }, '6. LIVE OPTION QUOTE JSON');

  const fetched = optionData?.fetched || [];
  const requestedTokens = new Set(selected.map(x => String(x.token)));
  const returned = fetched.filter(q => requestedTokens.has(String(q.symbolToken)));
  printSection('7. OPTION-CHAIN COVERAGE SUMMARY', {
    requestedContracts: selected.length,
    requestedCEContracts: ce.length,
    requestedPEContracts: pe.length,
    returnedQuoteCount: returned.length,
    returnedQuotesWithLtp: returned.filter(q => Number(q.ltp ?? q.lastTradedPrice) > 0).length,
    missingTokens: selected
      .filter(x => !returned.some(q => String(q.symbolToken) === String(x.token)))
      .map(x => ({ symbol: x.symbol, token: x.token }))
  });

  console.log('\nDIAGNOSTIC COMPLETED. This script only read market data; it did not place orders.');
}

main().catch(error => {
  console.error('\nDIAGNOSTIC FAILED:', error.message);
  console.error('No credentials or session tokens are printed by this script.');
  process.exitCode = 1;
});
